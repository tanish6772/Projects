package Tanish;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

import javax.swing.JTextField;

public class delete extends JFrame {
JLabel label1;
JTextField field1;
JButton button1;
public delete() {
	setLayout(new FlowLayout());
	label1 = new JLabel("Id");
	field1 = new JTextField(10);
	button1= new JButton("delete");
	button1.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			System.out.println("Deleted");
			Pogo po = new Pogo();
			po.setId(Integer.parseInt(field1.getText()));
			OpImp op = new OpImp();
			op.DeleteData(po);
			
		}
	});
		add(label1);
		add(field1);
		add(button1);
		setVisible(true);
		setSize(400, 400);


}
}
