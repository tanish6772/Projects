package Tanish;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class login extends JFrame {
	JLabel label1,label2;
	JTextField field1,field2;
	JButton button1,button2;
	
		public login() {
			setLayout(new FlowLayout());
			label1 = new JLabel("Id");
			label2 = new JLabel("Password");
			field1 = new JTextField(10);
			field2 = new JTextField(10);
			button1 = new JButton("Submit");
			button1.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					System.out.println("Login");
					if (field1.getText().equals("admin") && field2.getText().equals("admin")) {
						new Dashboard();
					} else {
						System.out.println("Wrong");
					}
					
				}
			});
		button2 = new JButton("Reset");
		
		
		
		
		add(label1);
		add(field1);
		add(label2);
		add(field2);
		add(button1);
		add(button2);
		setVisible(true);
		setSize(400, 400);
		}
	
	
		
	public static void main(String[] args) {
		new login();

	}

}
