package Tanish;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class Update extends JFrame{
	JLabel label1,label2;
	JTextField fiel1,field2;
	JButton button1;
	
	public Update() {
		setLayout(new FlowLayout());
		label1= new JLabel("Id");
		label2= new JLabel("Salary");
		fiel1= new JTextField(10);
		field2= new JTextField(10);
		button1 = new JButton("Update");
		button1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				System.out.println("Updated");
				Pogo po = new Pogo();
				po.setId(Integer.parseInt(fiel1.getText()));
				po.setSalary(Double.parseDouble(field2.getText()));
				OpImp op = new OpImp();
				op.updateData(po);
			}
		});
		
		add(label1);
		add(fiel1);
		add(label2);
		add(field2);
		add(button1);
		
		setVisible(true);
		setSize(400, 400);
		
		
	}
	
}
