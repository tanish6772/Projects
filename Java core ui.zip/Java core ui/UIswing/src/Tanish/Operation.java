package Tanish;

public interface Operation {
void insertData(Pogo po);
void updateData(Pogo po);
void DeleteData(Pogo po);
void showData(Pogo po);

}
