package Tanish;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class OpImp implements Operation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	@Override
	public void insertData(Pogo po) {
		PreparedStatement ps;
		try {
			ps=GetConnection.getConnection().prepareStatement("insert into jerry login(?,?,?)");
			ps.setInt(1, po.getId());
			ps.setString(2, po.getName());
			ps.setDouble(3, po.getSalary());
			System.out.println("Inserted");
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}

	@Override
	public void updateData(Pogo po) {
		PreparedStatement ps;
		try {
			ps=GetConnection.getConnection().prepareStatement("update login set salary=? where id=?");
			ps.setDouble(1, po.getSalary());
			ps.setInt(2, po.getId());
			ps.executeUpdate();
			System.out.println("Update");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	@Override
	public void DeleteData(Pogo po) {
		PreparedStatement ps;
		try {
			ps=GetConnection.getConnection().prepareStatement("delete from jerry where id= ?");
			ps.setInt(1, po.getId());
			ps.executeUpdate();
			System.out.println("Deleted");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		
		
	}

	@Override
	public void showData(Pogo po) {
		Statement s = null;
		try {
			s=GetConnection.getConnection().createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ResultSet rs = null;
		try {
			rs=s.executeQuery("select * from login");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			while (rs.next()) {
				System.out.println(rs.getInt(1));
				System.out.println(rs.getString(2));
				System.out.println(rs.getDouble(3));
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
