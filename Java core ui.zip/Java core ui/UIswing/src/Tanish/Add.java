package Tanish;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class Add extends JFrame{
JLabel label1,label2,label3;
JTextField field1,field2,field3;
JButton button1;
	
	public Add() {
		setLayout(new FlowLayout());
		label1 = new JLabel("id");
		label2 = new JLabel("name");
		label3 = new JLabel("salary");
		field1 = new JTextField(10);
		field2 = new JTextField(10);
		field3 = new JTextField(10);
		button1 = new JButton("Submit");
		button1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				System.out.println("Inserted");
				Pogo po = new Pogo();
				po.setId(Integer.parseInt(field1.getText()));
				po.setName(field2.getText());
				po.setSalary(Double.parseDouble(field3.getText()));
				OpImp op =  new OpImp();
				op.insertData(po);
				
			}
		});
	
	add(label1);
	add(field1);
	add(label2);
	add(field2);
	add(label3);
	add(field3);
	add(button1);
	setVisible(true);
	setSize(400, 400);
	}
	
	
	
}
